"""
Инициализация и миграция базы данных.

  python init_db.py          — создать таблицы; если пользователей нет, создать администратора
                               со случайным паролем (будет выведен ОДИН раз) или с паролем из ADMIN_PASSWORD
  python init_db.py --demo   — дополнительно создать тестовые учётные записи (только для разработки!)
"""
import os
import secrets
import sqlite3
import sys

from config import Config, BASE_DIR
from security import hash_password, validate_password_policy

DEMO_USERS = [
    ('admin', 'Admin123!', 'Администратор Комплекса', 'admin'),
    ('trainer', 'Trainer123!', 'Тренер Тренеров', 'trainer'),
    ('client', 'Client123!', 'Иванов Иван', 'client'),
]

DEMO_SERVICES = [
    ('Бассейн', 'Посещение плавательного бассейна 50m', 500.0),
    ('Тренажерный зал', 'Разовое посещение зала', 400.0),
]


def _generate_password() -> str:
    # Гарантированно соответствует политике паролей
    return 'Aa1!' + secrets.token_urlsafe(12)


def init_db(demo: bool = False):
    conn = sqlite3.connect(Config.DATABASE)
    conn.execute("PRAGMA foreign_keys = ON")
    cursor = conn.cursor()

    with open(os.path.join(BASE_DIR, 'schema.sql'), encoding='utf-8') as f:
        try:
            cursor.executescript(f.read())
        except sqlite3.IntegrityError as e:
            print(f"[WARN] Не удалось создать уникальный индекс записей (есть дубликаты): {e}")

    # Миграция: старая роль 'staff' -> 'trainer' (иначе тренер не получает доступ к заявкам)
    cursor.execute("UPDATE users SET role = 'trainer' WHERE role = 'staff'")
    # Защита от неизвестных ролей
    cursor.execute("UPDATE users SET role = 'client' WHERE role NOT IN ('admin', 'trainer', 'client')")

    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0 and not demo:
        password = os.environ.get('ADMIN_PASSWORD') or _generate_password()
        ok, msg = validate_password_policy(password, 'admin')
        if not ok:
            conn.close()
            sys.exit(f"[ERROR] ADMIN_PASSWORD не соответствует политике паролей: {msg}")
        cursor.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, 'admin')",
            ('admin', hash_password(password), 'Администратор Комплекса'))
        print("=" * 60)
        print(" Создан администратор.  Логин: admin")
        if not os.environ.get('ADMIN_PASSWORD'):
            print(f" Пароль: {password}")
            print(" Сохраните его сейчас — повторно он показан не будет.")
        print("=" * 60)

    if demo:
        print("[!] Режим --demo: тестовые аккаунты с известными паролями. Не используйте в боевом режиме.")
        for username, password, full_name, role in DEMO_USERS:
            cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
            if not cursor.fetchone():
                cursor.execute(
                    "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
                    (username, hash_password(password), full_name, role))
        for title, desc, price in DEMO_SERVICES:
            cursor.execute("SELECT id FROM services WHERE title = ?", (title,))
            if not cursor.fetchone():
                cursor.execute("INSERT INTO services (title, description, price) VALUES (?, ?, ?)",
                               (title, desc, price))

    conn.commit()
    conn.close()
    print("[OK] База данных успешно инициализирована.")


if __name__ == '__main__':
    init_db(demo='--demo' in sys.argv)
