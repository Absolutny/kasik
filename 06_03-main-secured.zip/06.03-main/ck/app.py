import math
import sqlite3
from datetime import date, timedelta

from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.middleware.proxy_fix import ProxyFix

from config import Config
from db import close_db, execute_query, execute_commit, execute_write
from security import (
    hash_password, verify_password, verify_dummy, validate_password_policy,
    sanitize_input, validate_username, validate_full_name,
    login_required, admin_required, trainer_required, client_required,
    set_security_headers, csrf_protect, generate_csrf_token, load_current_user, start_session,
)
from rate_limit import (
    limit_login_attempts, record_failed_attempt, clear_failed_attempts,
    get_remote_address, rate_limit,
)
from audit import log_event

app = Flask(__name__)
app.config.from_object(Config)

# Доверяем X-Forwarded-* только если явно указано число прокси перед приложением
if Config.TRUSTED_PROXY_COUNT > 0:
    n = Config.TRUSTED_PROXY_COUNT
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=n, x_proto=n, x_host=n)

app.teardown_appcontext(close_db)
app.before_request(load_current_user)
app.before_request(csrf_protect)
app.after_request(set_security_headers)
app.jinja_env.globals['csrf_token'] = generate_csrf_token

MAX_BOOKING_DAYS_AHEAD = 365
MAX_ACTIVE_BOOKINGS = 20


# --- Главная страница ---
@app.route('/')
def index():
    services = execute_query("SELECT * FROM services ORDER BY id DESC")
    return render_template('dashboard.html', services=services)


@app.route('/register', methods=['GET', 'POST'])
@rate_limit('register', max_calls=10, window=3600)
def register():
    """Самостоятельная регистрация клиентов."""
    if request.method == 'POST':
        username = sanitize_input(request.form.get('username', ''), 32)
        password = request.form.get('password', '')
        full_name = sanitize_input(request.form.get('full_name', ''), 100)

        for ok, msg in (validate_username(username), validate_full_name(full_name),
                        validate_password_policy(password, username)):
            if not ok:
                flash(msg, "danger")
                return render_template('register.html')

        existing = execute_query("SELECT id FROM users WHERE username = ? COLLATE NOCASE", (username,), one=True)
        if existing:
            flash("Пользователь с таким логином уже существует.", "danger")
            return render_template('register.html')

        try:
            execute_commit(
                "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, 'client')",
                (username, hash_password(password), full_name)
            )
        except sqlite3.IntegrityError:
            flash("Пользователь с таким логином уже существует.", "danger")
            return render_template('register.html')

        log_event("REGISTER", f"Зарегистрирован новый клиент: {username}", username=username)
        flash("Регистрация успешна! Теперь вы можете войти.", "success")
        return redirect(url_for('login'))

    return render_template('register.html')


# --- Авторизация и Выход ---
@app.route('/login', methods=['GET', 'POST'])
@limit_login_attempts
def login():
    if request.method == 'POST':
        username = sanitize_input(request.form.get('username', ''), 64)
        password = request.form.get('password', '')
        ip = get_remote_address()

        user = execute_query("SELECT * FROM users WHERE username = ? COLLATE NOCASE", (username,), one=True)

        if user and verify_password(user['password_hash'], password):
            clear_failed_attempts(ip, username)
            start_session(user)

            log_event("LOGIN_SUCCESS", f"Вход пользователя {user['username']} ({user['role']})",
                      user_id=user['id'], username=user['username'])
            flash("Вы успешно вошли в систему.", "success")
            return redirect(url_for('index'))

        if not user:
            verify_dummy(password)   # одинаковое время ответа для существующих и несуществующих логинов
        record_failed_attempt(ip, username)
        log_event("LOGIN_FAILED", f"Неудачный вход: {username}", username=username[:64] or 'anonymous')
        flash("Неверный логин или пароль.", "danger")

    return render_template('login.html')


@app.route('/logout', methods=['POST'])
@login_required
def logout():
    log_event("LOGOUT", "Пользователь вышел из системы")
    session.clear()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for('login'))


@app.route('/change_password', methods=['GET', 'POST'])
@login_required
@rate_limit('change_password', max_calls=10, window=900, per_user=True)
def change_password():
    """Смена собственного пароля. После смены все остальные сессии пользователя становятся недействительными."""
    if request.method == 'POST':
        current = request.form.get('current_password', '')
        new = request.form.get('new_password', '')
        confirm = request.form.get('confirm_password', '')

        user = execute_query("SELECT * FROM users WHERE id = ?", (session['user_id'],), one=True)
        if not verify_password(user['password_hash'], current):
            log_event("PASSWORD_CHANGE_FAILED", "Неверный текущий пароль при смене пароля")
            flash("Текущий пароль указан неверно.", "danger")
            return render_template('change_password.html')
        if new != confirm:
            flash("Новый пароль и подтверждение не совпадают.", "danger")
            return render_template('change_password.html')
        if verify_password(user['password_hash'], new):
            flash("Новый пароль должен отличаться от текущего.", "danger")
            return render_template('change_password.html')
        ok, msg = validate_password_policy(new, user['username'])
        if not ok:
            flash(msg, "danger")
            return render_template('change_password.html')

        execute_commit("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(new), user['id']))
        log_event("PASSWORD_CHANGED", "Пользователь изменил пароль")
        fresh = execute_query("SELECT * FROM users WHERE id = ?", (user['id'],), one=True)
        start_session(fresh)   # текущая сессия продолжает работать, остальные — нет
        flash("Пароль успешно изменён.", "success")
        return redirect(url_for('index'))

    return render_template('change_password.html')


# --- Функционал АДМИНИСТРАТОРА ---

@app.route('/admin/add_service', methods=['GET', 'POST'])
@admin_required
def add_service():
    """Создание новой услуги (Админ)."""
    if request.method == 'POST':
        title = sanitize_input(request.form.get('title', ''), 100)
        description = sanitize_input(request.form.get('description', ''), 500)

        if not (2 <= len(title) <= 100):
            flash("Название услуги: от 2 до 100 символов.", "danger")
            return render_template('add_service.html')
        try:
            price = float(request.form.get('price', '').replace(',', '.'))
        except ValueError:
            flash("Некорректная цена.", "danger")
            return render_template('add_service.html')
        if not math.isfinite(price) or price <= 0 or price > 1_000_000:
            flash("Цена должна быть больше 0 и не превышать 1 000 000.", "danger")
            return render_template('add_service.html')
        price = round(price, 2)

        execute_commit(
            "INSERT INTO services (title, description, price) VALUES (?, ?, ?)",
            (title, description, price)
        )
        log_event("SERVICE_CREATED", f"Администратор создал услугу '{title}' ({price} руб.)")
        flash(f"Услуга '{title}' успешно добавлена!", "success")
        return redirect(url_for('index'))

    return render_template('add_service.html')


@app.route('/admin/hire_trainer', methods=['GET', 'POST'])
@admin_required
def hire_trainer():
    """Найм нового тренера (Админ)."""
    if request.method == 'POST':
        username = sanitize_input(request.form.get('username', ''), 32)
        password = request.form.get('password', '')
        full_name = sanitize_input(request.form.get('full_name', ''), 100)

        for ok, msg in (validate_username(username), validate_full_name(full_name),
                        validate_password_policy(password, username)):
            if not ok:
                flash(msg, "danger")
                return render_template('hire_trainer.html')

        existing = execute_query("SELECT id FROM users WHERE username = ? COLLATE NOCASE", (username,), one=True)
        if existing:
            flash("Пользователь с таким логином уже зарегистрирован.", "danger")
            return render_template('hire_trainer.html')

        try:
            execute_commit(
                "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, 'trainer')",
                (username, hash_password(password), full_name)
            )
        except sqlite3.IntegrityError:
            flash("Пользователь с таким логином уже зарегистрирован.", "danger")
            return render_template('hire_trainer.html')

        log_event("TRAINER_HIRED", f"Администратор зарегистрировал тренера {full_name} ({username})")
        flash(f"Тренер '{full_name}' успешно нанят!", "success")
        return redirect(url_for('index'))

    return render_template('hire_trainer.html')


# --- Функционал КЛИЕНТА ---

@app.route('/book_service/<int:service_id>', methods=['POST'])
@client_required
@rate_limit('book', max_calls=30, window=3600, per_user=True)
def book_service(service_id):
    """Отправка заявки на запись клиентом."""
    service = execute_query("SELECT id FROM services WHERE id = ?", (service_id,), one=True)
    if not service:
        flash("Выбранная услуга не найдена.", "danger")
        return redirect(url_for('index'))

    raw_date = sanitize_input(request.form.get('booking_date', ''), 10)
    try:
        booking_date = date.fromisoformat(raw_date)
    except ValueError:
        flash("Укажите корректную дату записи.", "warning")
        return redirect(url_for('index'))

    today = date.today()
    if booking_date < today:
        flash("Нельзя записаться на прошедшую дату.", "warning")
        return redirect(url_for('index'))
    if booking_date > today + timedelta(days=MAX_BOOKING_DAYS_AHEAD):
        flash("Запись возможна не более чем на год вперёд.", "warning")
        return redirect(url_for('index'))

    active = execute_query(
        "SELECT COUNT(*) AS c FROM bookings WHERE client_id = ? AND status = 'pending'",
        (session['user_id'],), one=True)['c']
    if active >= MAX_ACTIVE_BOOKINGS:
        flash("Слишком много заявок на рассмотрении. Дождитесь ответа тренера.", "warning")
        return redirect(url_for('my_bookings'))

    try:
        execute_commit(
            "INSERT INTO bookings (client_id, service_id, booking_date, status) VALUES (?, ?, ?, 'pending')",
            (session['user_id'], service_id, booking_date.isoformat())
        )
    except sqlite3.IntegrityError:
        flash("У вас уже есть заявка на эту услугу на выбранную дату.", "warning")
        return redirect(url_for('my_bookings'))

    log_event("BOOKING_SUBMITTED", f"Клиент {session['username']} создал заявку на услугу #{service_id}")
    flash("Заявка успешно отправлена! Ожидайте подтверждения тренера.", "success")
    return redirect(url_for('my_bookings'))


@app.route('/my_bookings')
@login_required
def my_bookings():
    """Просмотр клиентом своих заявок (только собственных — фильтр по session['user_id'])."""
    bookings = execute_query('''
        SELECT b.id, s.title, s.price, b.booking_date, b.status, b.created_at
        FROM bookings b
        JOIN services s ON b.service_id = s.id
        WHERE b.client_id = ?
        ORDER BY b.created_at DESC
    ''', (session['user_id'],))
    return render_template('my_bookings.html', bookings=bookings)


# --- Функционал ТРЕНЕРА ---

@app.route('/trainer/bookings')
@trainer_required
def trainer_bookings():
    """Просмотр заявок тренером."""
    bookings = execute_query('''
        SELECT b.id, u.full_name as client_name, s.title as service_title, b.booking_date, b.status, b.created_at
        FROM bookings b
        JOIN users u ON b.client_id = u.id
        JOIN services s ON b.service_id = s.id
        ORDER BY CASE WHEN b.status = 'pending' THEN 0 ELSE 1 END, b.created_at DESC
    ''')
    return render_template('trainer_bookings.html', bookings=bookings)


@app.route('/trainer/booking/<int:booking_id>/<action>', methods=['POST'])
@trainer_required
def process_booking(booking_id, action):
    """Принятие или отклонение заявки тренером (только для заявок «на рассмотрении»)."""
    if action not in ('accept', 'reject'):
        flash("Недопустимое действие.", "danger")
        return redirect(url_for('trainer_bookings'))

    new_status = 'accepted' if action == 'accept' else 'rejected'
    # Атомарная смена статуса: обработать можно только заявку в статусе pending
    changed = execute_write(
        "UPDATE bookings SET status = ? WHERE id = ? AND status = 'pending'", (new_status, booking_id))
    if not changed:
        flash("Заявка не найдена или уже обработана.", "warning")
        return redirect(url_for('trainer_bookings'))

    status_text = "принята" if action == 'accept' else "отклонена"
    log_event("BOOKING_PROCESSED", f"Тренер {session['username']} изменил статус заявки #{booking_id} на {new_status}")
    flash(f"Заявка #{booking_id} {status_text}.", "info")
    return redirect(url_for('trainer_bookings'))


@app.route('/audit_log')
@admin_required
def audit_log():
    per_page = 50
    page = request.args.get('page', 1, type=int) or 1
    page = max(1, min(page, 10_000))
    total = execute_query("SELECT COUNT(*) AS c FROM audit_logs", one=True)['c']
    logs = execute_query(
        "SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?", (per_page, (page - 1) * per_page))
    pages = max(1, (total + per_page - 1) // per_page)
    return render_template('audit_log.html', logs=logs, page=page, pages=pages, total=total)


# --- Обработка ошибок (без утечки технических подробностей) ---

def _error(code, title, message):
    return render_template('error.html', code=code, title=title, message=message), code


@app.errorhandler(400)
def bad_request(e):
    if getattr(e, 'description', '') == 'csrf':
        return _error(400, "Запрос отклонён",
                      "Форма устарела или не прошла проверку безопасности. Обновите страницу и повторите действие.")
    return _error(400, "Некорректный запрос", "Сервер не смог обработать запрос.")


@app.errorhandler(403)
def forbidden(e):
    return _error(403, "Доступ запрещён", "У вас недостаточно прав для просмотра этой страницы.")


@app.errorhandler(404)
def not_found(e):
    return _error(404, "Страница не найдена", "Запрашиваемая страница не найдена.")


@app.errorhandler(405)
def method_not_allowed(e):
    return _error(405, "Метод не поддерживается", "Для этого адреса данный тип запроса недопустим.")


@app.errorhandler(413)
def too_large(e):
    return _error(413, "Слишком большой запрос", "Размер отправленных данных превышает допустимый.")


@app.errorhandler(429)
def too_many(e):
    return _error(429, "Слишком много запросов", "Повторите попытку позже.")


@app.errorhandler(500)
def internal_error(e):
    return _error(500, "Внутренняя ошибка сервера", "Произошла внутренняя ошибка. Обратитесь к администратору.")


if __name__ == '__main__':
    host, debug = Config.HOST, Config.DEBUG
    # Отладчик Werkzeug = удалённое выполнение кода. В сеть он не выставляется никогда.
    if debug and host not in ('127.0.0.1', 'localhost', '::1'):
        print("[SECURITY] Режим отладки отключён: он недопустим при доступе из сети.")
        debug = False

    if Config.BACKUP_ENABLED and (not debug or __import__('os').environ.get('WERKZEUG_RUN_MAIN') == 'true'):
        from backup import start_backup_thread
        start_backup_thread()

    app.run(host=host, port=Config.PORT, debug=debug)
