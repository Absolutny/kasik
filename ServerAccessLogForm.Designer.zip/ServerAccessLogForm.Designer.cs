namespace SupportDesk.forms
{
    partial class ServerAccessLogForm
    {
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ServerAccessLogForm
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "ServerAccessLogForm";
            this.Load += new System.EventHandler(this.ServerAccessLogForm_Load);
            this.ResumeLayout(false);

        }
    }
}
